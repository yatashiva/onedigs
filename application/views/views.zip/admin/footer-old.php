<div class="page-footer">
            <div class="page-footer-inner"> 2018 &copy;
            <a href="" target="_top" class="makerCss"></a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>