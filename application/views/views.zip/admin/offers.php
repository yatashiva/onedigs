	<div class="d-flex flex-column-fluid">
							<!--begin::Container-->
							<div class="container">
							    <div class="row">
							          <div class="col-xl-12" style="margin-top:30px">
							        
							        
							     <center> <img src="https://res.cloudinary.com/mallinamala/image/upload/v1618141765/undraw_under_construction_46pa_aaykd2.svg" class="img-fluid" width="500px"><br><br>
							     <h6>Coming Soon</h6>
							     </center>
							     
							        </div>
							        </div>
							        </div>
							        </div>
							        
							        

                    
