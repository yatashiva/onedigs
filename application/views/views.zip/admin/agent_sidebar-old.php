<div class="sidebar-container">
 				<div class="sidemenu-container navbar-collapse collapse fixed-menu">
	                <div id="remove-scroll">
	                    <ul class="sidemenu  page-header-fixed" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
	                        <li class="sidebar-toggler-wrapper hide">
	                            <div class="sidebar-toggler">
	                                <span></span>
	                            </div>
	                        </li>
	                        <li class="sidebar-user-panel">
	                            <div class="user-panel">
	                                <!-- <div class="pull-left image">
	                                    <img src="<?php echo base_url(); ?>assets/admin/img/dp.jpg" class="img-circle user-img-circle" alt="User Image" />
	                                </div> -->
	                                <div class="pull-left info">
	                                    <p> <?php echo '';?></p>
	                                   
	                                </div>
	                            </div>
	                        </li>
	                        <li class="nav-item start active">
	                            <a href="<?php echo base_url(); ?>/index.php/admin/dashboard" class="nav-link nav-toggle">
	                                <i class="material-icons">dashboard</i>
	                                <span class="title">Dashboard</span>
                                	<span class="selected"></span>
                                
	                            </a>
	               
	                        </li>
						
						
						
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/reservation/reservations_by_agent" class="nav-link nav-toggle">
								<i class="material-icons">event</i>
								<span class="title">Bookings</span>
							</a>
						</li>
		
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/travel_agent/amount_gained" class="nav-link nav-toggle">
								<i class="material-icons">receipt</i>
								<span class="title">Gained Amount</span>
							</a>
						</li>
						
						
						
	                    </ul>
	                </div>
                </div>
            </div>