<div class="sidebar-container">
 				<div class="sidemenu-container navbar-collapse collapse fixed-menu">
	                <div id="remove-scroll">
	                    <ul class="sidemenu  page-header-fixed" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px;width:230px;">
	                        <li class="sidebar-toggler-wrapper hide">
	                            <div class="sidebar-toggler">
	                                <span></span>
	                            </div>
	                        </li>
	                        <li class="sidebar-user-panel">
	                            <div class="user-panel">
	                                <!-- <div class="pull-left image">
	                                    <img src="<?php echo base_url(); ?>assets/admin/img/dp.jpg" class="img-circle user-img-circle" alt="User Image" />
	                                </div> -->
	                                <div class="pull-left info">
	                                    <p> <?php echo '';?></p>
	                                   
	                                </div>
	                            </div>
	                        </li>
	                        <li class="nav-item start active">
	                            <a href="<?php echo base_url(); ?>index.php/admin/dashboard" class="nav-link nav-toggle">
	                                <i class="material-icons">dashboard</i>
	                                <span class="title">Dashboard</span>
                                	<span class="selected"></span>
                                
	                            </a>
	               
	                        </li>
						<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
								<i class="material-icons">store</i>
								<span class="title">Hotels</span>
								<span class="arrow"></span>
							</a>
							<ul class="sub-menu">
	                                <li class="nav-item   ">
											<a href="<?php echo base_url();?>index.php/hotel/" class="nav-link ">
	                                        <span class="title">View Hotels</span>
	                                    </a>
	                                </li>
	                                
	                                <li class="nav-item">
	                                    <a href="<?php echo base_url();?>index.php/hotel/add" class="nav-link ">
	                                        <span class="title">Add Hotel</span>
	                                    </a>
	                                </li>
									 <!-- <li class="nav-item"> -->
	                                    <!-- <a href="<?php echo base_url();?>index.php/hotel/add2" class="nav-link "> -->
	                                        <!-- <span class="title">Add Hotel Sample</span> -->
	                                    <!-- </a> -->
	                                <!-- </li> -->
	                        </ul>
						</li>

						<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
								<i class="material-icons">room</i>
								<span class="title">Room types</span>
								<span class="arrow"></span>
							</a>
							<ul class="sub-menu">
	                                <li class="nav-item   ">
											<a href="<?php echo base_url();?>index.php/room_category/" class="nav-link ">
	                                        <span class="title">View Room types</span>
	                                    </a>
	                                </li>
	                                
	                                <li class="nav-item">
	                                    <a href="<?php echo base_url();?>index.php/room_category/add" class="nav-link ">
	                                        <span class="title">Add Room type</span>
	                                    </a>
	                                </li>
	                                <li class="nav-item">
	                                    <a href="<?php echo base_url();?>index.php/room_category/addsub" class="nav-link ">
	                                        <span class="title">Add Sub Room types</span>
	                                    </a>
	                                </li>
	                                 <li class="nav-item">
	                                    <a href="<?php echo base_url();?>index.php/room_category/viewsub" class="nav-link ">
	                                        <span class="title">View Sub Room types</span>
	                                    </a>
	                                </li>
	                            </ul>
						</li>
						<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
								<i class="material-icons">perm_identity</i>
								<span class="title">Hotel Vendor</span>
								<span class="arrow"></span>
							</a>
							<ul class="sub-menu">
	                                <li class="nav-item   ">
											<a href="<?php echo base_url();?>index.php/vendor_detail/" class="nav-link ">
	                                        <span class="title">View Hotel Vendor</span>
	                                    </a>
	                                </li>
	                                
	                                <li class="nav-item">
	                                    <a href="<?php echo base_url();?>index.php/vendor_detail/add" class="nav-link ">
	                                        <span class="title">Add Hotel Vendor</span>
	                                    </a>
	                                </li>
	                            </ul>
						</li>
						<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
								<i class="material-icons">perm_identity</i>
								<span class="title">Taxes</span>
								<span class="arrow"></span>
							</a>
							<ul class="sub-menu">
	                                <li class="nav-item   ">
											<a href="<?php echo base_url();?>index.php/taxes/" class="nav-link ">
	                                        <span class="title">View Taxes</span>
	                                    </a>
	                                </li>
	                                
	                                <li class="nav-item">
	                                    <a href="<?php echo base_url();?>index.php/taxes/add" class="nav-link ">
	                                        <span class="title">Add tax</span>
	                                    </a>
	                                </li>
	                            </ul>
						</li>
						<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
								<i class="fa fa-taxi"></i>
								<span class="title">Travel Agent</span>
								<span class="arrow"></span>
							</a>
							<ul class="sub-menu">
	                                <li class="nav-item   ">
											<a href="<?php echo base_url();?>index.php/travel_agent/" class="nav-link ">
	                                        <span class="title">View Travel Agents</span>
	                                    </a>
	                                </li>
	                                
	                                <li class="nav-item">
	                                    <a href="<?php echo base_url();?>index.php/travel_agent/add" class="nav-link ">
	                                        <span class="title">Add Travel Agnet</span>
	                                    </a>
	                                </li>
	                            </ul>
						</li>						
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/user_detail/" class="nav-link nav-toggle">
								<i class="material-icons">perm_identity</i>
								<span class="title">Users</span>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/reservation" class="nav-link nav-toggle">
								<i class="material-icons">event</i>
								<span class="title">Bookings</span>
							</a>
						</li>
						<!-- <li class="nav-item">
							<a href="<?php echo base_url();?>index.php/payment_detail" class="nav-link nav-toggle">
								<i class="material-icons">receipt</i>
								<span class="title">Payments</span>
							</a>
						</li> -->
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/inventory/gethotels" class="nav-link nav-toggle">
								<i class="material-icons">today</i>
								<span class="title">Inventory</span>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/margin/" class="nav-link nav-toggle">
								<i class="material-icons">receipt</i>
								<span class="title">Payment Margins</span>
							</a>
						</li>

						<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
								<i class="material-icons">stars</i>
								<span class="title">Extras</span>
								<span class="arrow"></span>
							</a>
							<ul class="sub-menu">
	                                <li class="nav-item   ">
											<a href="<?php echo base_url();?>index.php/amenity/" class="nav-link ">
	                                        <span class="title">View amenities</span>
	                                    </a>
	                                </li>
									<li class="nav-item   ">
											<a href="<?php echo base_url();?>index.php/trending_destinations/" class="nav-link ">
	                                        <span class="title">Trending Destinations</span>
	                                    </a>
	                                </li>
	                            </ul>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/hotel/promotions" class="nav-link nav-toggle">
								<i class="material-icons">star</i>
								<span class="title">Promotions</span>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>index.php/hotel/offers" class="nav-link nav-toggle">
								<i class="material-icons">star</i>
								<span class="title">Offers</span>
							</a>
						</li>
	                    </ul>
	                </div>
                </div>
            </div>