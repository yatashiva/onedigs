<?php include("header.php"); ?>


<style>
	.p_font p{
		font-size: 10pt;
	}

</style>
<div class="container" style='margin-top:2%;margin-bottom:2%'>
	
		<h1 style='text-align:center;color:Red'>FAQ</h1>
	<div class='col-md-8 p_font'>	
	<h2>What is NOHO?</h2>	
	
	<p>NOHO Rooms, commonly known as NOHO, is an Indian hospitality service and budget hotel network.The precursor to the modern hotel was the inn of medieval Europe. For a period of about 200 years from the mid-17th century, coaching inns served as a place for lodging for coach travelers. </p>
	
	
	<br>
	<h2>How do I locate the NOHO for my current upcoming booking?</h2>
	
	<p>NOHO is always at your fingertips even if you face any difficulty in locating us.</p>
	
	<p>1. If you have booked through App, use the NOHO App to navigate to your location</p>

	<p>	2. Use Map link sent over SMS to navigate</p>

		<p>3. Call the property front desk for directions to your NOHO</p>

	<p>	4. Please check your Booking Confirmation Mail for Directions and Map Link to your hotel</p>

	<p>	5. Go to Bookings page under Manage Bookings section on Website to find directions</p>

	<p>	6. Call the NOHO helpline</p>
	
	
	<br>
	<h2>How can I extend my booking?</h2>
	
	<p>Confused about the journey dates? You can extend your booking subject to availability at the hotel. You can easily get in touch with us on our guest support helpline for the extending dates. However, new tariff will be applicable for the duration. </p>
	
	
	</div>	
</div>		

<?php include("footer.php"); ?>				