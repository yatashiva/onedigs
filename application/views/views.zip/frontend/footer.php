	<div class="hom-footer-section">
		<div class="container">
			<div class="row">
				<div class="foot-com foot-1">
					<ul>
						<li><a href="#">About Us</a>
						</li>
						<li style="padding-left:10px;font-size:16px"><a href="#">Privacy Policy</a>
						</li>
						<li style="padding-left:10px;font-size:16px"><a href="#">Terms & Conditions</a>
						</li>
						<li style="padding-left:10px;font-size:16px"><a href="#">Help</a>
						</li>
					</ul>
				</div>
			
				<div class="foot-com foot-3">
					<p>&copy; Olakite</p> </div>
				<!--<div class="foot-com foot-4">-->
				<!--	<a href="#"><img src="images/payment-method.svg" alt="" />-->
				<!--	</a>-->
				<!--</div>-->
			</div>
		</div>
	</div>
	<!--ALL SCRIPT FILES-->
	<script src="<?php echo base_url(); ?>assets/frontend2/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/frontend2/js/jquery-ui.js"></script>
	<script src="<?php echo base_url(); ?>assets/frontend2/js/angular.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/frontend2/js/bootstrap.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/frontend2/js/materialize.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/frontend2/js/jquery.mixitup.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/frontend2/js/custom.js"></script>
</body>

</html>