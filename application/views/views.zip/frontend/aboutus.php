<?php include("header.php"); ?>

<div class="container" style='margin-top:2%;margin-bottom:2%'>
	
		<h1 style='text-align:center;color:Red'>About Us</h1>
		
		<br>
		<div class='col-md-12'>
		<p>noho rooms is new generation budgeted hotels has established in India for all hotel booking as travel agent. We are focused on price which is reliable and affordable to our customer.</p>
		
		<p>We know the importance of travel how it’s part of individual life, either for business, pilgrim or pleasure visit. We Believe travel has the power to experience.</p>
		
		<p>You can experience and visit our mobile/site for last minute deals and offer’s. noho is committed to ensure your stay is memorable.</p>
		<br>
		<h2>Vision</h2>
		<p>
		“To become the premiere provider and facilitator of leisure and vacation experiences across Indian Cities with reliable and cost efficiency” 
		</P>
		<br>
		<h2>Mission</h2>
		<p>“To enhance the lives of our customers by creating and enabling unsurpassed vacation and leisure experiences” </p>
		</div>
		
		<!-- <div class='col-md-6'>
			<img src='<?php echo base_url();?>gallery/admin_login_images/Mercure_hotel_taksim.jpg' class='img-responsive center-block'  style='padding-top:60px' />
		</div> -->
		<p></p>
		<p></p>
		
</div>		

<?php include("footer.php"); ?>		